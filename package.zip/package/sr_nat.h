
#ifndef SR_NAT_TABLE_H
#define SR_NAT_TABLE_H

/*#define ICMP_QUERY_TIMEOUT 60
#define TCP_ESTABLISHED_TIMEOUT 7440
#define TCP_TRANSITORY_TIMEOUT 300
#define ENABLE_NAT 0 */


#include <inttypes.h>
#include <time.h>
#include <pthread.h>
#include "sr_router.h"
#include "sr_if.h"
#include "sr_router.h"

typedef enum {
  nat_mapping_icmp,
  nat_mapping_tcp
  /* nat_mapping_udp, */
} sr_nat_mapping_type;

/*TCP states*/
typedef enum{
	CLOSED,
	LISTEN,
	LISTEN_RCV_SYN,
	SYN_RCVD,
	SYN_SENT,
	SYN_SENT_RCV_SYN,
	SYN_SENT_RCV_SYN_ACK,
	ESTAB,
	ESTAB_RCV_FIN,
	FIN_WAIT_1,
	FIN_WAIT_1_RCV_FIN,
	CLOSE_WAIT,
	FIN_WAIT_2,
	FIN_WAIT_2_RCV_FIN,
	CLOSING,
	LAST_ACK,
	TIME_WAIT,
	DEFAULT
} sr_nat_tcp_state;

struct sr_nat_connection {
  /* add TCP connection state data members here */
  uint32_t ip_src;
  uint32_t ip_dst;
  uint16_t port_src;
  uint16_t port_dst;
  uint32_t seq_num_in;
  uint32_t seq_num_out;
  time_t last_updated;
  sr_nat_tcp_state state;
  
  struct sr_nat_connection *next;
};

struct sr_nat_mapping {
  sr_nat_mapping_type type;
  uint32_t ip_int; /* internal ip addr */
  uint32_t ip_ext; /* external ip addr */
  uint16_t aux_int; /* internal port or icmp id */
  uint16_t aux_ext; /* external port or icmp id */
  time_t last_updated; /* use to timeout mappings */
  struct sr_nat_connection *conns; /* list of connections. null for ICMP */
  struct sr_nat_mapping *next;
};

struct sr_nat_tcp_packet  {
	uint8_t *buf;               /* A raw Ethernet frame */
    unsigned int len;           /* Length of raw Ethernet frame */
    time_t time_received;       /* Use to timeout*/
    struct sr_nat_tcp_packet *next;
};

struct sr_nat {
  /* add any fields here */
  struct sr_nat_mapping *mappings;
  
  int32_t icmp_query_timeout;
  int32_t tcp_established_timeout;
  int32_t tcp_transitory_timeout;
  
  int16_t icmp_id_counter;
  int16_t tcp_port_counter;
  
  struct sr_nat_tcp_packet* syn_cache;   /* unsolicited inbound TCP SYN cache */
  
  /* threading */
  pthread_mutex_t lock;
  pthread_mutexattr_t attr;
  pthread_attr_t thread_attr;
  pthread_t thread;
};


int   sr_nat_init(struct sr_instance* sr, struct sr_nat *nat);     /* Initializes the nat */
int   sr_nat_destroy(struct sr_nat *nat);  /* Destroys the nat (free memory) */
void *sr_nat_timeout(void *nat_ptr);  /* Periodic Timout */

/* Get the mapping associated with given external port.
   You must free the returned structure if it is not NULL. */
struct sr_nat_mapping *sr_nat_lookup_external(struct sr_nat *nat,
    uint16_t aux_ext, sr_nat_mapping_type type );

/* Get the mapping associated with given internal (ip, port) pair.
   You must free the returned structure if it is not NULL. */
struct sr_nat_mapping *sr_nat_lookup_internal(struct sr_nat *nat,
  uint32_t ip_int, uint16_t aux_int, sr_nat_mapping_type type );

/* Insert a new mapping into the nat's mapping table.
   You must free the returned structure if it is not NULL. */
struct sr_nat_mapping *sr_nat_insert_mapping(struct sr_instance* sr, struct sr_nat *nat,
  uint32_t ip_int, uint16_t aux_int, sr_nat_mapping_type type,  char* interface );

struct sr_nat_connection *sr_nat_lookup_conn(struct sr_nat *nat, struct sr_nat_mapping *mapping,
          uint32_t ip_src, uint32_t ip_dst, uint16_t port_src, uint16_t port_dst);
struct sr_nat_connection *sr_nat_insert_conn(struct sr_nat *nat, struct sr_nat_mapping *mapping,
  uint32_t ip_src, uint32_t ip_dst, uint16_t port_src, uint16_t port_dst);

void sr_nat_add_syn_cache (struct sr_nat *nat, uint8_t *packet, unsigned int packet_len);
void sr_nat_remove_syn_packet (struct sr_nat *nat, int32_t ip_dst, uint16_t port_dst, uint16_t port_src);

uint16_t sr_nat_gen_port(struct sr_nat *nat, uint16_t init);
int change_conn_state(struct sr_nat *nat, struct sr_nat_mapping* mapping_entry, sr_tcp_hdr_t * tcp_hdr_ptr, struct sr_nat_connection * conn, int in_to_ex);
#endif
