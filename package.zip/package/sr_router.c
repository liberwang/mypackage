/**********************************************************************
* file:  sr_router.c
* date:  Mon Feb 18 12:50:42 PST 2002
* Contact: casado@stanford.edu
*
* Description:
*
* This file contains all the functions that interact directly
* with the routing table, as well as the main entry method
* for routing.
*
**********************************************************************/

#include <stdio.h>
#include <assert.h>
#include "stdlib.h"
#include <string.h>

#include "sr_if.h"
#include "sr_rt.h"
#include "sr_router.h"
#include "sr_protocol.h"
#include "sr_arpcache.h"
#include "sr_utils.h"
#include "sr_nat.h"

/*---------------------------------------------------------------------
* Method: sr_init(void)
* Scope:  Global
*
* Initialize the routing subsystem
*
*---------------------------------------------------------------------*/

void sr_init(struct sr_instance* sr, struct sr_nat* sn)
{
    /* REQUIRES */
    assert(sr);
    
    /* Initialize cache and cache cleanup thread */
    sr_arpcache_init(&(sr->cache));
    
    pthread_attr_init(&(sr->attr));
    pthread_attr_setdetachstate(&(sr->attr), PTHREAD_CREATE_JOINABLE);
    pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
    pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
    pthread_t thread;
    
    pthread_create(&thread, &(sr->attr), sr_arpcache_timeout, sr);

    /* Add initialization code here! */
    sr->nat = sn;
    
} /* -- sr_init -- */

/*---------------------------------------------------------------------
* Method: sr_handlepacket(uint8_t* p,char* interface)
* Scope:  Global
*
* This method is called each time the router receives a packet on the
* interface.  The packet buffer, the packet length and the receiving
* interface are passed in as parameters. The packet is complete with
* ethernet headers.
*
* Note: Both the packet buffer and the character's memory are handled
* by sr_vns_comm.c that means do NOT delete either.  Make a copy of the
* packet instead if you intend to keep it around beyond the scope of
* the method call.
*
*---------------------------------------------------------------------*/

void sr_handlepacket(struct sr_instance* sr,
uint8_t * packet/* lent */,
unsigned int len,
char* interface/* lent */){
    /* REQUIRES */
    assert(sr);
    assert(packet);
    assert(interface);
    printf("*** -> Received packet of length %d\n", len);
    
    /* Ethernet Frame Validation */
    /* fill in code here */
    /* check size first, then check ip or arp size seperately */
    if (sizeof(sr_ethernet_hdr_t) > len) {
        return;
    }

    if (ethertype(packet) == ethertype_ip) {
        if (sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t) <= len) {
            /* it is ip packet*/
            sr_handleip(sr, packet, len, interface);
        }
    }
    else if (ethertype(packet) == ethertype_arp) {
        if (sizeof(sr_ethernet_hdr_t) + sizeof(sr_arp_hdr_t) <= len) {
            /* it is arp packet*/
            sr_handlearp(sr, packet, interface);
        }
    }
}/* end sr_ForwardPacket */

void sr_handlearp(
    struct sr_instance* sr,
    uint8_t * packet,
    char* interface) {

    sr_arp_hdr_t *sr_arp = (sr_arp_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t));

    /* this arp is not to me */
    if (sr_get_interface(sr, interface)->ip != sr_arp->ar_tip) {
        return;
    }

    /*printf("sr_handlearp: ARP Packet, \n");*/
    if (ntohs(sr_arp->ar_op) == arp_op_request) {
        /*print_hdrs(packet, len);*/
        send_arp_packet(sr, packet, interface);
    }
    else if (ntohs(sr_arp->ar_op) == arp_op_reply) {
        struct sr_arpreq *req = sr_arpcache_insert(&(sr->cache), sr_arp->ar_sha, sr_arp->ar_sip);

        if (req != NULL) {
            struct sr_packet * current_packet = req->packets;
            while (current_packet != NULL) {
                memcpy(current_packet->buf, sr_arp->ar_sha, ETHER_ADDR_LEN);
                memcpy(current_packet->buf + ETHER_ADDR_LEN, (sr_get_interface(sr, interface))->addr, ETHER_ADDR_LEN);

                sr_send_packet(sr, current_packet->buf, current_packet->len, interface);
                current_packet = current_packet->next;
            }
            sr_arpreq_destroy(&(sr->cache), req);
        }
    }
}

void sr_handleip_old(
    struct sr_instance* sr,
    uint8_t * packet,
    unsigned int len,
    char* interface) {

    printf("sr_handleip : ip packet");
    print_hdrs(packet, len);

    sr_ip_hdr_t* ip_hdr = (sr_ip_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t));

    /* check checksum first */
    uint16_t ip_sum_new;
    uint16_t ip_sum_old;
    ip_sum_old = ip_hdr->ip_sum;
    ip_hdr->ip_sum = 0;
    ip_sum_new = cksum(ip_hdr, sizeof(sr_ip_hdr_t));

    if (ip_sum_new != ip_sum_old) {
        /*printf("sr_handleip : checksum error.\n"); */
        return;
    }
    ip_hdr->ip_sum = ip_sum_new;

    /* check ip in interface table*/
    struct sr_if* sr_if_entry = NULL;
    struct sr_if* sr_ip_if = sr->if_list;

    while (sr_ip_if) {
        if (sr_ip_if->ip == ip_hdr->ip_dst) {
            sr_if_entry = sr_ip_if;
            break;
        }
        sr_ip_if = sr_ip_if->next;
    }


    if (sr_if_entry != NULL) {
        /*printf( "sr_handleip: this one is send to me.\n" );*/

        struct sr_rt* rt_entry = search_longest_prefix(sr, ip_hdr->ip_src);
        if (rt_entry == NULL) {
            /*printf("sr_handleip: Couldn't find in routing table\n"); */
            return;
        }

        if (ip_hdr->ip_p == ip_protocol_icmp) {
            struct sr_icmp_hdr* icmp_hdr = (struct sr_icmp_hdr*)(packet + sizeof(struct sr_ethernet_hdr) + sizeof(struct sr_ip_hdr));
            uint16_t icmp_sum_new;
            uint16_t icmp_sum_old;

            icmp_sum_old = icmp_hdr->icmp_sum;
            icmp_hdr->icmp_sum = 0;
            icmp_sum_new = cksum(icmp_hdr, len - sizeof(sr_ethernet_hdr_t) - sizeof(sr_ip_hdr_t));

            if (icmp_sum_old != icmp_sum_new)
            {
                /*printf("sr_handleip: chksum not right\n"); */
                return;
            }
            icmp_hdr->icmp_sum = icmp_sum_old;

            send_icmp_packet_echoreply(sr, packet, len, rt_entry->interface, ip_hdr->ip_dst, rt_entry->gw.s_addr, 0, 0);
        }
        else {
            printf("sr_handleip: port unreachable! \n");
            send_icmp_packet_portunreach(sr, packet, rt_entry->interface, rt_entry->gw.s_addr, 3, 3);
        }
    }
    else {
        if (ip_hdr->ip_ttl <= 1) {
            struct sr_rt* rt_entry = search_longest_prefix(sr, ip_hdr->ip_src);
            if (rt_entry != NULL) {
                struct sr_if *sr_if_entry = sr_get_interface(sr, rt_entry->interface);
                send_icmp_packet(sr, packet, rt_entry->interface, sr_if_entry->ip, rt_entry->gw.s_addr, 11, 0);
            }
        }
        else {
            int ip_hdr_size = sizeof(sr_ip_hdr_t);
            ip_hdr->ip_ttl--;
            ip_hdr->ip_sum = 0;
            ip_hdr->ip_sum = cksum(ip_hdr, ip_hdr_size);

            struct sr_rt* rt_entry = search_longest_prefix(sr, ip_hdr->ip_dst);

            if (rt_entry == NULL) {
                rt_entry = search_longest_prefix(sr, ip_hdr->ip_src);
                if (rt_entry != NULL) {
                    struct sr_if *sr_if_entry = sr_get_interface(sr, rt_entry->interface);
                    send_icmp_packet(sr, packet, rt_entry->interface, sr_if_entry->ip, rt_entry->gw.s_addr, 3, 0);
                }
            }
            else {
                send_lookup_packet(sr, packet, rt_entry->gw.s_addr, len, rt_entry->interface);
            }
        }
    }
}


void sr_handleip(
    struct sr_instance* sr, 
    uint8_t * packet,
    unsigned int len, 
    char* interface){

    sr_ip_hdr_t* org_ip_hdr = (sr_ip_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t));
    struct sr_rt* rt_entry = search_longest_prefix(sr, org_ip_hdr->ip_dst);
    struct sr_if* if_entry = get_ip_interface(sr, org_ip_hdr->ip_dst);

    struct sr_if* in_if_entry = sr_get_interface(sr, INTERNAL_IF);
    struct sr_rt* scr_rt_entry = search_longest_prefix(sr, org_ip_hdr->ip_src);
    struct sr_if* src_if_entry = sr_get_interface(sr, scr_rt_entry->interface);

 
    uint16_t ip_sum_new;
    uint16_t ip_sum_old;
    ip_sum_old = org_ip_hdr->ip_sum;
    org_ip_hdr->ip_sum = 0;
    ip_sum_new = cksum(org_ip_hdr, sizeof(sr_ip_hdr_t));
    
    if (ip_sum_new != ip_sum_old) {
        printf("error of checksum\n");
        return;
    }
    org_ip_hdr->ip_sum = ip_sum_old;
    
    if (sr->nat != NULL){
		pthread_mutex_lock(&(sr->nat->lock));

		sr_nat_mapping_type type;
		uint16_t port_or_id = 0;
		if(org_ip_hdr->ip_p == ip_protocol_icmp){
			type = nat_mapping_icmp;
			uint8_t *icmp_packet = (uint8_t *)(packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
			port_or_id = get_id_from_icmp(icmp_packet);

		}else{
			sr_tcp_hdr_t* tcp_hdr_ptr = (sr_tcp_hdr_t*)(packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
			type = nat_mapping_tcp;
			port_or_id = tcp_hdr_ptr->tcp_dst_port;
		}
		struct sr_nat_mapping * nat_entry = NULL;
		if (src_if_entry != in_if_entry && if_entry != NULL){
			nat_entry = sr_nat_lookup_external(sr->nat, port_or_id, type);
		}
		
        if (if_entry != NULL && nat_entry == NULL && org_ip_hdr->ip_p == ip_protocol_icmp){
            rt_entry = search_longest_prefix(sr, org_ip_hdr->ip_src);
            if (rt_entry == NULL){
                pthread_mutex_unlock(&(sr->nat->lock));
                return;
            }
            if(org_ip_hdr->ip_p == ip_protocol_icmp){
                struct sr_icmp_hdr* icmp_hdr= (struct sr_icmp_hdr*)(packet + sizeof(struct sr_ethernet_hdr) + sizeof(struct sr_ip_hdr));

               
                ip_sum_old = icmp_hdr->icmp_sum;
                icmp_hdr->icmp_sum = 0;
                ip_sum_new = cksum(icmp_hdr, len- sizeof(sr_ethernet_hdr_t) - sizeof(sr_ip_hdr_t));
                
                if (ip_sum_old != ip_sum_new){
                    printf("check sum error\n");
                    pthread_mutex_unlock(&(sr->nat->lock));
                    return;
                }
                icmp_hdr->icmp_sum = ip_sum_old;

                send_icmp_packet_echoreply(sr, packet, len, rt_entry->interface, org_ip_hdr->ip_dst, rt_entry->gw.s_addr, 0, 0);
            } else {
                send_icmp_packet(sr, packet, rt_entry->interface, org_ip_hdr->ip_dst, rt_entry->gw.s_addr, 3, 3);
            }
        }else{ /*not mine*/			
            if (org_ip_hdr->ip_ttl <= 1){
				rt_entry = search_longest_prefix(sr, org_ip_hdr->ip_src);
				if (rt_entry == NULL){
					pthread_mutex_unlock(&(sr->nat->lock));
					return;
				}
				send_icmp_packet(sr, packet, rt_entry->interface, sr_get_interface(sr, rt_entry->interface)->ip, rt_entry->gw.s_addr, 11, 0);
				pthread_mutex_unlock(&(sr->nat->lock));
				return;
			}
			
            uint8_t* new_packet = NULL;
            if(org_ip_hdr->ip_p == ip_protocol_icmp){
                new_packet = nat_modify_icmp_packet(sr, packet, len, interface);
            }else{
                new_packet = nat_modify_tcp_packet(sr, packet, len, interface);
            }
            if (new_packet){
                sr_handleip_old(sr, new_packet, len, interface);
            }
        }
        if(nat_entry!=NULL){
			free(nat_entry);
		}
		pthread_mutex_unlock(&(sr->nat->lock));
		
    } else {
		sr_handleip_old(sr, packet, len, interface);
    }
}

    
uint8_t* nat_modify_icmp_packet(
    struct sr_instance* sr, 
    uint8_t* packet,
    unsigned int len, 
    char* interface){

    uint8_t* new_packet = (uint8_t*)malloc(len);
    memcpy(new_packet, packet, len);
    sr_ip_hdr_t* ip_hdr_ptr = (sr_ip_hdr_t*)(new_packet + sizeof(sr_ethernet_hdr_t));
    sr_icmp_hdr_t* icmp_hdr_ptr = (sr_icmp_hdr_t*)(new_packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
    unsigned int icmp_len = len - sizeof(sr_ethernet_hdr_t) - sizeof(sr_ip_hdr_t);
    
    uint16_t ip_sum_new;
    uint16_t ip_sum_old;
    ip_sum_old = icmp_hdr_ptr->icmp_sum;
    icmp_hdr_ptr->icmp_sum = 0;
    ip_sum_new = cksum(icmp_hdr_ptr, icmp_len);
    
    if (ip_sum_new != ip_sum_old) {
        free(new_packet);
        return NULL;
    }
    icmp_hdr_ptr->icmp_sum = ip_sum_old;

    struct sr_if* in_if_entry = sr_get_interface(sr, INTERNAL_IF);
    
    struct sr_rt* scr_rt_entry = search_longest_prefix(sr, ip_hdr_ptr->ip_src);
    struct sr_if* src_if_entry = sr_get_interface(sr, scr_rt_entry->interface);
    struct sr_rt* rt_entry = search_longest_prefix(sr, ip_hdr_ptr->ip_dst);
    struct sr_if* dst_if_entry = NULL;
    if (rt_entry){
		dst_if_entry = sr_get_interface(sr, rt_entry->interface);
	}else{
		dst_if_entry = get_ip_interface(sr, ip_hdr_ptr->ip_dst);
	}
        
    
    if (dst_if_entry != NULL && rt_entry != NULL && dst_if_entry != in_if_entry && src_if_entry == in_if_entry) {

		uint16_t port_or_id = get_id_from_icmp((uint8_t *)icmp_hdr_ptr);
		struct sr_nat_mapping * nat_entry = sr_nat_lookup_internal(sr->nat, ip_hdr_ptr->ip_src, port_or_id, nat_mapping_icmp);		
		if(nat_entry ==NULL){
			struct sr_rt* rt_entry = search_longest_prefix(sr, ip_hdr_ptr->ip_dst);
			if (rt_entry){
				nat_entry = sr_nat_insert_mapping(sr, sr->nat, ip_hdr_ptr->ip_src, 
				port_or_id, nat_mapping_icmp, rt_entry->interface);
			} else {
				free(new_packet);
				return NULL;
			}
		}
			
		modify_icmp_id_or_port((uint8_t *)icmp_hdr_ptr, icmp_len, nat_entry->aux_ext);
		
        ip_hdr_ptr->ip_src = nat_entry->ip_ext;
        ip_hdr_ptr->ip_sum = 0;
        ip_hdr_ptr->ip_sum = cksum(ip_hdr_ptr, sizeof(sr_ip_hdr_t));

        free(nat_entry);
        return new_packet;
     } else if (src_if_entry != in_if_entry && dst_if_entry != NULL){
        
		uint16_t port_or_id = get_id_from_icmp((uint8_t *)icmp_hdr_ptr);
        struct sr_nat_mapping * nat_entry = sr_nat_lookup_external(	sr->nat, port_or_id, nat_mapping_icmp);
		if(nat_entry == NULL){
			return new_packet;
		}
		ip_hdr_ptr->ip_dst = nat_entry->ip_int;
        ip_hdr_ptr->ip_sum = 0;
        ip_hdr_ptr->ip_sum = cksum(ip_hdr_ptr, sizeof(sr_ip_hdr_t));
        
        modify_icmp_id_or_port((uint8_t *)icmp_hdr_ptr, icmp_len, nat_entry->aux_int);

        free(nat_entry);
        return new_packet;
    } else if ((src_if_entry != in_if_entry && (dst_if_entry != in_if_entry)) || (src_if_entry == in_if_entry)){
		return new_packet;
    }

	free(new_packet);
	return NULL;
}

uint8_t* nat_modify_tcp_packet(
    struct sr_instance* sr, 
    uint8_t* packet,
    unsigned int len, 
    char* interface){

    uint8_t* new_packet = (uint8_t*)malloc(len); 
    sr_ip_hdr_t* ip_hdr_ptr = (sr_ip_hdr_t*)(new_packet + sizeof(sr_ethernet_hdr_t));
    sr_tcp_hdr_t* tcp_hdr_ptr = (sr_tcp_hdr_t*)(new_packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
    unsigned int tcp_len = len - sizeof(sr_ethernet_hdr_t) - sizeof(sr_ip_hdr_t);
    memcpy(new_packet, packet, len);
    
    uint8_t * pseudo_packet = (uint8_t*)malloc(tcp_len + sizeof(sr_tcp_pseudo_hdr_t));
    
    sr_tcp_pseudo_hdr_t * pseudo_hdr = (sr_tcp_pseudo_hdr_t*)(pseudo_packet);
    sr_tcp_hdr_t * pseudo_tcp_hdr_ptr = (sr_tcp_hdr_t*)(pseudo_packet+sizeof(sr_tcp_pseudo_hdr_t));
    memcpy(pseudo_tcp_hdr_ptr, tcp_hdr_ptr, tcp_len);
    pseudo_hdr->dst_ip = ip_hdr_ptr->ip_dst;
    pseudo_hdr->src_ip = ip_hdr_ptr->ip_src;
    pseudo_hdr->protocol = ip_hdr_ptr->ip_p;
    pseudo_hdr->tcp_seg_len = htons(tcp_len);
    pseudo_hdr->reserved = 0;
    pseudo_tcp_hdr_ptr->tcp_sum = 0;
    if (cksum(pseudo_packet, sizeof(sr_tcp_pseudo_hdr_t)+tcp_len) != tcp_hdr_ptr->tcp_sum) {

        free(new_packet);
        free(pseudo_packet);
        return NULL;
    }
    
    struct sr_if* in_if_entry = sr_get_interface(sr, INTERNAL_IF);
    
    struct sr_rt* scr_rt_entry = search_longest_prefix(sr, ip_hdr_ptr->ip_src);
    struct sr_if* src_if_entry = sr_get_interface(sr, scr_rt_entry->interface);
    struct sr_rt* rt_entry = search_longest_prefix(sr, ip_hdr_ptr->ip_dst);
    struct sr_if* dst_if_entry = NULL;
    if (rt_entry){
		dst_if_entry = sr_get_interface(sr, rt_entry->interface);
	}else{
		dst_if_entry = get_ip_interface(sr, ip_hdr_ptr->ip_dst);
	}
    
    if (dst_if_entry != NULL && rt_entry != NULL && dst_if_entry != in_if_entry && src_if_entry == in_if_entry) {
        struct sr_nat_mapping * copy = sr_nat_lookup_internal(sr->nat, ip_hdr_ptr->ip_src, tcp_hdr_ptr->tcp_src_port, nat_mapping_tcp);
        if (copy == NULL) {
			struct sr_rt* rt_entry = search_longest_prefix(sr, ip_hdr_ptr->ip_dst);
			if (rt_entry){
				copy = sr_nat_insert_mapping(sr, sr->nat, ip_hdr_ptr->ip_src, 
				tcp_hdr_ptr->tcp_src_port, nat_mapping_tcp, rt_entry->interface);
			} else {
				free(new_packet);
				return NULL;
			}
        }
        
        ip_hdr_ptr->ip_src = copy->ip_ext;
        pseudo_hdr->src_ip = ip_hdr_ptr->ip_src;
        ip_hdr_ptr->ip_sum = 0;
        ip_hdr_ptr->ip_sum = cksum(ip_hdr_ptr, sizeof(sr_ip_hdr_t));

        tcp_hdr_ptr->tcp_src_port = copy->aux_ext;
        tcp_hdr_ptr->tcp_sum = 0;
        memcpy(pseudo_tcp_hdr_ptr, tcp_hdr_ptr, tcp_len);
        tcp_hdr_ptr->tcp_sum = cksum(pseudo_packet, sizeof(sr_tcp_pseudo_hdr_t)+tcp_len);
        free(pseudo_packet);

        struct sr_nat_connection * conn = sr_nat_lookup_conn(sr->nat, copy,
        ip_hdr_ptr->ip_src, ip_hdr_ptr->ip_dst, tcp_hdr_ptr->tcp_src_port, tcp_hdr_ptr->tcp_dst_port);
        if (conn == NULL) {
            if ((ntohs(tcp_hdr_ptr->tcp_ctl_bits) & 2) == 2){ /* end SYN*/

				conn = sr_nat_insert_conn(sr->nat, copy,
				ip_hdr_ptr->ip_src, ip_hdr_ptr->ip_dst, tcp_hdr_ptr->tcp_src_port, tcp_hdr_ptr->tcp_dst_port);

				sr_nat_remove_syn_packet (sr->nat, ip_hdr_ptr->ip_dst, tcp_hdr_ptr->tcp_dst_port, tcp_hdr_ptr->tcp_src_port);
			}
        }
        
		if (change_conn_state(sr->nat, copy, tcp_hdr_ptr, conn, 1) == 0 ){
			free(copy);
			free(conn);
			free(new_packet);
			return NULL;
		}; 
		return new_packet;
    } else if (src_if_entry != in_if_entry && dst_if_entry != NULL ){
       
        struct sr_nat_mapping * copy = sr_nat_lookup_external(sr->nat, tcp_hdr_ptr->tcp_dst_port, nat_mapping_tcp);

        if (copy == NULL) {
			if (get_ip_interface(sr, ip_hdr_ptr->ip_dst) && (ntohs(tcp_hdr_ptr->tcp_dst_port)>1023 || ntohs(tcp_hdr_ptr->tcp_dst_port) == 22)){ 
				if ((ntohs(tcp_hdr_ptr->tcp_ctl_bits) & 2) == 2){ 
                    if (ntohs(tcp_hdr_ptr->tcp_dst_port)>1023 )
					    sr_nat_add_syn_cache (sr->nat, packet, len);
                    else
                    {
                        send_icmp_packet(sr, packet, scr_rt_entry->interface, ip_hdr_ptr->ip_dst, scr_rt_entry->gw.s_addr, 3, 3);
                    }
				}
			} else if (dst_if_entry != in_if_entry){
				free(pseudo_packet);
				return new_packet;
			}
			free(pseudo_packet);
			free(new_packet);
			return NULL;
        }
        
        struct sr_nat_connection * conn = sr_nat_lookup_conn(sr->nat, copy,
        ip_hdr_ptr->ip_dst, ip_hdr_ptr->ip_src, tcp_hdr_ptr->tcp_dst_port, tcp_hdr_ptr->tcp_src_port);
        if (conn == NULL) {

			if ((ntohs(tcp_hdr_ptr->tcp_ctl_bits) & 2) == 2){ /* rcv SYN*/

			    conn = sr_nat_insert_conn(sr->nat, copy,
			    ip_hdr_ptr->ip_dst, ip_hdr_ptr->ip_src, tcp_hdr_ptr->tcp_dst_port, tcp_hdr_ptr->tcp_src_port);

			    sr_nat_remove_syn_packet (sr->nat, ip_hdr_ptr->ip_src, tcp_hdr_ptr->tcp_src_port, tcp_hdr_ptr->tcp_dst_port);


			} else {
				free(pseudo_packet);
				free(copy);
				free(new_packet);
				return NULL;
			}
			
        }
        ip_hdr_ptr->ip_dst = copy->ip_int;
        pseudo_hdr->dst_ip = ip_hdr_ptr->ip_dst;
        ip_hdr_ptr->ip_sum = 0;
        ip_hdr_ptr->ip_sum = cksum(ip_hdr_ptr, sizeof(sr_ip_hdr_t));
        tcp_hdr_ptr->tcp_dst_port = copy->aux_int;
        tcp_hdr_ptr->tcp_sum = 0;
        memcpy(pseudo_tcp_hdr_ptr, tcp_hdr_ptr, tcp_len);
        tcp_hdr_ptr->tcp_sum = cksum(pseudo_packet, sizeof(sr_tcp_pseudo_hdr_t)+tcp_len);
        free(pseudo_packet);

        
        if (change_conn_state(sr->nat, copy, tcp_hdr_ptr, conn, 0)==0){
			free(copy);
			free(conn);
			free(new_packet);
			return NULL;
		} 
        free(copy);
		free(conn);
        return new_packet;
    } else if ((src_if_entry != in_if_entry && (dst_if_entry != in_if_entry))
    || (src_if_entry == in_if_entry)){
		free(pseudo_packet);
		return new_packet;
    }
    free(new_packet);
    return NULL;
    
}

void send_arp_packet(
    struct sr_instance* sr,
    uint8_t * packet,
    char* interface) {

    sr_arp_hdr_t *sr_arp = (sr_arp_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t));
    struct sr_if *sr_interface = sr_get_interface(sr, interface);

    sr_arp_hdr_t *sr_arp_reply = (sr_arp_hdr_t*)malloc(sizeof(sr_arp_hdr_t));
    sr_arp_reply->ar_hrd = htons(arp_hrd_ethernet);
    sr_arp_reply->ar_pro = htons(ethertype_ip);
    sr_arp_reply->ar_hln = ETHER_ADDR_LEN;
    sr_arp_reply->ar_pln = sr_arp->ar_pln;
    sr_arp_reply->ar_op = ntohs(arp_op_reply);
    memcpy(sr_arp_reply->ar_sha, sr_interface->addr, ETHER_ADDR_LEN);
    sr_arp_reply->ar_sip = sr_arp->ar_tip;
    memcpy(sr_arp_reply->ar_tha, sr_arp->ar_sha, ETHER_ADDR_LEN);
    sr_arp_reply->ar_tip = sr_arp->ar_sip;

    sr_ethernet_hdr_t* sr_ether_reply = (sr_ethernet_hdr_t*)malloc(sizeof(sr_ethernet_hdr_t));
    sr_ether_reply->ether_type = htons(ethertype_arp);
    memcpy(sr_ether_reply->ether_dhost, ((sr_ethernet_hdr_t *)packet)->ether_shost, ETHER_ADDR_LEN);
    memcpy(sr_ether_reply->ether_shost, sr_interface->addr, ETHER_ADDR_LEN);

    uint8_t* reply_packet = (uint8_t*)malloc(sizeof(sr_ethernet_hdr_t) + sizeof(sr_arp_hdr_t));
    memcpy(reply_packet, sr_ether_reply, sizeof(sr_ethernet_hdr_t));
    memcpy(reply_packet + sizeof(sr_ethernet_hdr_t), sr_arp_reply, sizeof(sr_arp_hdr_t));
    sr_send_packet(sr, reply_packet, sizeof(sr_ethernet_hdr_t) + sizeof(sr_arp_hdr_t), sr_interface->name);

    free(sr_ether_reply);
    free(reply_packet);
    free(sr_arp_reply);

}

void send_arp_reply_packet(
    struct sr_instance* sr, 
    uint8_t * packet,
    unsigned int len, 
    char* interface){
    

    sr_arp_hdr_t* org_arp = (sr_arp_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t));
    struct sr_if* pck_intf = sr_get_interface(sr, interface);
    
    /* Creat ARP Header */
    sr_arp_hdr_t* reply_arp = (sr_arp_hdr_t*)malloc(sizeof(sr_arp_hdr_t));
    reply_arp->ar_hrd = htons(arp_hrd_ethernet);     
    reply_arp->ar_pro = htons(ethertype_ip);         
    reply_arp->ar_hln = ETHER_ADDR_LEN;              
    reply_arp->ar_pln = org_arp->ar_pln;             
    reply_arp->ar_op = ntohs(arp_op_reply);          
    memcpy(reply_arp->ar_sha, pck_intf->addr, ETHER_ADDR_LEN);
    reply_arp->ar_sip = org_arp->ar_tip;
    memcpy(reply_arp->ar_tha, org_arp->ar_sha, ETHER_ADDR_LEN);
    reply_arp->ar_tip = org_arp->ar_sip;

    sr_ethernet_hdr_t* org_ether = (sr_ethernet_hdr_t *)packet;
    sr_ethernet_hdr_t* reply_ether = (sr_ethernet_hdr_t*)malloc(sizeof(sr_ethernet_hdr_t));
    memcpy(reply_ether->ether_dhost, org_ether->ether_shost, ETHER_ADDR_LEN);  
    memcpy(reply_ether->ether_shost, pck_intf->addr, ETHER_ADDR_LEN);     
    reply_ether->ether_type = htons(ethertype_arp);
    

    uint8_t* reply_packet = (uint8_t*)malloc(sizeof(sr_ethernet_hdr_t) + sizeof(sr_arp_hdr_t));
    memcpy(reply_packet, reply_ether, sizeof(sr_ethernet_hdr_t));
    memcpy(reply_packet + sizeof(sr_ethernet_hdr_t), reply_arp, sizeof(sr_arp_hdr_t));

    sr_send_packet(sr, reply_packet, sizeof(sr_ethernet_hdr_t) + sizeof(sr_arp_hdr_t), pck_intf->name);

    free(reply_arp);
    free(reply_ether);
    free(reply_packet);
}

void send_arp_request_packet(
    struct sr_instance* sr,
    const char* interface_name, 
    uint32_t dest_ip){

    struct sr_if* if_entry = sr_get_interface(sr, interface_name);
    sr_print_if(if_entry);
    
    sr_ethernet_hdr_t* request_ether = (sr_ethernet_hdr_t*)malloc(sizeof(sr_ethernet_hdr_t));
    memcpy(request_ether->ether_shost, if_entry->addr, ETHER_ADDR_LEN);
    int i;
    for(i=0; i<ETHER_ADDR_LEN; i++)
        request_ether->ether_dhost[i] = 255;
    request_ether->ether_type=htons(ethertype_arp);
    
    sr_arp_hdr_t* request_arp = (sr_arp_hdr_t*)malloc(sizeof(sr_arp_hdr_t));
    request_arp->ar_hrd = htons(arp_hrd_ethernet);     
    request_arp->ar_pro = htons(ethertype_ip);         
    request_arp->ar_hln = ETHER_ADDR_LEN;              
    request_arp->ar_pln = 4;             			  
    request_arp->ar_op = htons(arp_op_request);       
    
    memcpy(request_arp->ar_sha, if_entry->addr, ETHER_ADDR_LEN);
    request_arp->ar_sip = if_entry->ip;
    for(i=0; i<ETHER_ADDR_LEN; i++)
        request_arp->ar_tha[i] = 255;
    request_arp->ar_tip = dest_ip;
    

    int total_size = sizeof(sr_ethernet_hdr_t) + sizeof(sr_arp_hdr_t);
    uint8_t* request_packet = (uint8_t*)malloc(total_size);
    memcpy(request_packet, request_ether, sizeof(sr_ethernet_hdr_t));
    memcpy(request_packet + sizeof(sr_ethernet_hdr_t), request_arp, sizeof(sr_arp_hdr_t));

    sr_send_packet(sr, request_packet, total_size, if_entry->name);
    
    free(request_ether);
    free(request_arp);
    free(request_packet);
}

void send_icmp_packet_echoreply(
    struct sr_instance* sr, 
    uint8_t * packet, 
    unsigned int len,
    char* interface, 
    uint32_t src_ip, 
    uint32_t next_hop_ip, 
    int in_icmp_type, 
    int in_icmp_code){
   

    int ether_hdr_size = sizeof(sr_ethernet_hdr_t);
    int ip_hdr_size = sizeof(sr_ip_hdr_t); 
    int icmp_hdr_size = sizeof(sr_icmp_hdr_t); 
    int icmp_whole_size = len - ether_hdr_size - ip_hdr_size;
    int total_size = ether_hdr_size + ip_hdr_size + icmp_whole_size;
    struct sr_if* intf = sr_get_interface(sr, interface);
    

    sr_ethernet_hdr_t* org_ether = (sr_ethernet_hdr_t *)packet;
    sr_ethernet_hdr_t* icmp_ether_hdr =
    create_ether_hdr(org_ether->ether_shost, intf->addr, ethertype_ip);
    

    sr_ip_hdr_t* org_ip = (sr_ip_hdr_t *)(packet + ether_hdr_size);
    sr_ip_hdr_t* icmp_ip_hdr = (sr_ip_hdr_t*)malloc(ip_hdr_size);

    icmp_ip_hdr->ip_v = 4;
    icmp_ip_hdr->ip_hl = ip_hdr_size/4;
    icmp_ip_hdr->ip_tos = 0;
    icmp_ip_hdr->ip_len = htons(ip_hdr_size + icmp_whole_size);
    icmp_ip_hdr->ip_id = org_ip->ip_id;
    icmp_ip_hdr->ip_off = htons(IP_DF);
    icmp_ip_hdr->ip_ttl = 64;
    icmp_ip_hdr->ip_p = ip_protocol_icmp;
    icmp_ip_hdr->ip_dst = org_ip->ip_src;
    icmp_ip_hdr->ip_src = src_ip;
    icmp_ip_hdr->ip_sum = 0;
    icmp_ip_hdr->ip_sum = cksum(icmp_ip_hdr, ip_hdr_size);


    uint8_t* icmp_data = (uint8_t*)malloc(icmp_whole_size);
    sr_icmp_hdr_t* icmp_hdr = (sr_icmp_hdr_t*)icmp_data;
    
    icmp_hdr->icmp_type = in_icmp_type;
    icmp_hdr->icmp_code = in_icmp_code;
    icmp_hdr->icmp_sum = 0;
    memcpy(icmp_data + icmp_hdr_size, packet + ether_hdr_size + ip_hdr_size + icmp_hdr_size, icmp_whole_size - icmp_hdr_size);
    
    icmp_hdr->icmp_sum = cksum(icmp_data, icmp_whole_size);


    uint8_t* icmp_packet = (uint8_t*)malloc(total_size);
    memcpy(icmp_packet, icmp_ether_hdr, ether_hdr_size);
    memcpy(icmp_packet + ether_hdr_size, icmp_ip_hdr, ip_hdr_size);
    memcpy(icmp_packet + ether_hdr_size + ip_hdr_size, icmp_data, icmp_whole_size);
    
    send_lookup_packet(sr, icmp_packet, next_hop_ip, total_size, interface);
    
    free(icmp_ether_hdr);
    free(icmp_ip_hdr);
    free(icmp_data);
    free(icmp_packet);
}


void send_icmp_packet(
    struct sr_instance* sr, 
    uint8_t * packet,
    char* interface, 
    uint32_t src_ip, 
    uint32_t next_hop_ip, 
    int in_icmp_type, 
    int in_icmp_code){

    int ether_hdr_size = sizeof(sr_ethernet_hdr_t);
    int ip_hdr_size = sizeof(sr_ip_hdr_t); 
    int icmp_hdr_size = sizeof(sr_icmp_t3_hdr_t); 
    int hdr_total_size = ether_hdr_size + ip_hdr_size + icmp_hdr_size;
    sr_ethernet_hdr_t* org_ether = (sr_ethernet_hdr_t *)packet;
    sr_ip_hdr_t* org_ip_hdr = (sr_ip_hdr_t*)(packet + ether_hdr_size);
    struct sr_if* intf = sr_get_interface(sr, interface);
    

    sr_ethernet_hdr_t* icmp_ether_hdr =
    create_ether_hdr(org_ether->ether_shost, intf->addr, ethertype_ip);
    

    sr_ip_hdr_t* icmp_ip_hdr = (sr_ip_hdr_t*)malloc(ip_hdr_size);
    icmp_ip_hdr->ip_v = 4;
    icmp_ip_hdr->ip_hl = ip_hdr_size/4;
    icmp_ip_hdr->ip_tos = 0;
    icmp_ip_hdr->ip_len = htons(ip_hdr_size + icmp_hdr_size);
    icmp_ip_hdr->ip_id = org_ip_hdr->ip_id;
    icmp_ip_hdr->ip_off = htons(IP_DF);
    icmp_ip_hdr->ip_ttl = 64;              
    icmp_ip_hdr->ip_p = ip_protocol_icmp;  
    icmp_ip_hdr->ip_dst = org_ip_hdr->ip_src; 
    icmp_ip_hdr->ip_src = src_ip;
    icmp_ip_hdr->ip_sum = 0;
    icmp_ip_hdr->ip_sum = cksum(icmp_ip_hdr, ip_hdr_size);

    sr_icmp_t3_hdr_t* icmp_hdr;
    icmp_hdr = (sr_icmp_t3_hdr_t*)malloc(icmp_hdr_size);
    icmp_hdr->icmp_type = in_icmp_type; 
    icmp_hdr->icmp_code = in_icmp_code; 
    icmp_hdr->icmp_sum = 0;
    icmp_hdr->unused = 0;
    icmp_hdr->next_mtu = 0;
    

    memcpy(icmp_hdr->data, packet + ether_hdr_size, ICMP_DATA_SIZE);
    icmp_hdr->icmp_sum = cksum(icmp_hdr, icmp_hdr_size);

    uint8_t* icmp_packet = (uint8_t*)malloc(hdr_total_size);
    memcpy(icmp_packet, icmp_ether_hdr, sizeof(sr_ethernet_hdr_t));
    memcpy(icmp_packet + ether_hdr_size, icmp_ip_hdr, ip_hdr_size);
    memcpy(icmp_packet + ether_hdr_size + ip_hdr_size, icmp_hdr, sizeof(sr_icmp_t3_hdr_t));
    
    send_lookup_packet(sr, icmp_packet, next_hop_ip, hdr_total_size, interface);
    
    free(icmp_hdr);
    free(icmp_ether_hdr);
    free(icmp_ip_hdr);
    free(icmp_packet);
}

sr_ethernet_hdr_t* create_ether_hdr(uint8_t* dhost, uint8_t* shost, uint16_t type){
    sr_ethernet_hdr_t* ether_hdr = (sr_ethernet_hdr_t*)malloc(sizeof(sr_ethernet_hdr_t));
    memcpy(ether_hdr->ether_dhost, dhost, ETHER_ADDR_LEN);  
    memcpy(ether_hdr->ether_shost, shost, ETHER_ADDR_LEN);  
    ether_hdr->ether_type = htons(type);
    return ether_hdr;
}

struct sr_if* get_ip_interface(struct sr_instance* sr, uint32_t ip){
    struct sr_if* if_entry = NULL;
    assert(ip);
    assert(sr);
    
    if_entry = sr->if_list;
    while(if_entry){
        if(if_entry->ip == ip)
        return if_entry;
        if_entry = if_entry->next;
    }
    return NULL;
} 

struct sr_rt* search_longest_prefix(
    struct sr_instance *sr,
    uint32_t ip) {

    uint32_t max = 0;
    struct sr_rt* cur_entry = sr->routing_table;
    struct sr_rt* return_entry = NULL;

    while (cur_entry != NULL) {
        if ((cur_entry->dest.s_addr & cur_entry->mask.s_addr) == (ip & cur_entry->mask.s_addr)) {
            if (max <= cur_entry->mask.s_addr) {
                max = cur_entry->mask.s_addr;
                return_entry = cur_entry;
            }
        }
        cur_entry = cur_entry->next;
    }
    return return_entry;
}

uint16_t get_id_from_icmp(uint8_t *icmp_buf) {
    sr_icmp_hdr_t *icmp_hdr = (sr_icmp_hdr_t *)(icmp_buf);
    if (icmp_hdr->icmp_type == 8 || icmp_hdr->icmp_type == 0) {
        sr_icmp_t08_hdr_t* icmp_t08_hdr = (sr_icmp_t08_hdr_t *)(icmp_hdr);
        return icmp_t08_hdr->icmp_id;
    }
    else if (icmp_hdr->icmp_type == 3) {
        sr_icmp_t3_hdr_t* icmp_t3_hdr = (sr_icmp_t3_hdr_t *)(icmp_buf);
        sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *)(icmp_t3_hdr->data);
        if (ip_hdr->ip_p == ip_protocol_icmp) {
            sr_icmp_t08_hdr_t* icmp_t08_hdr = (sr_icmp_t08_hdr_t *)(ip_hdr + sizeof(sr_ip_hdr_t));
            return icmp_t08_hdr->icmp_id;
        }
        else {
            sr_tcp_hdr_t *tcp_hdr = (sr_tcp_hdr_t *)(ip_hdr + sizeof(sr_ip_hdr_t));
            return tcp_hdr->tcp_src_port;
        }
    }
    return -1;
}

void modify_icmp_id_or_port(uint8_t *icmp_buf, unsigned int icmp_len, uint16_t port_or_id) {
    sr_icmp_hdr_t *icmp_hdr = (sr_icmp_hdr_t *)(icmp_buf);
    if (icmp_hdr->icmp_type == 8 || icmp_hdr->icmp_type == 0) {
        sr_icmp_t08_hdr_t* icmp_t08_hdr = (sr_icmp_t08_hdr_t *)(icmp_hdr);
        icmp_t08_hdr->icmp_id = port_or_id;
        icmp_t08_hdr->icmp_sum = 0;
        icmp_t08_hdr->icmp_sum = cksum(icmp_t08_hdr, icmp_len);
    }
    else if (icmp_hdr->icmp_type == 3) {
        sr_icmp_t3_hdr_t* icmp_t3_hdr = (sr_icmp_t3_hdr_t *)(icmp_buf);
        sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *)(icmp_t3_hdr->data);

        if (ip_hdr->ip_p == ip_protocol_icmp) {
            sr_icmp_t08_hdr_t* icmp_t08_hdr = (sr_icmp_t08_hdr_t *)(ip_hdr + sizeof(sr_ip_hdr_t));
            icmp_t08_hdr->icmp_id = port_or_id;
        }
        else {
            sr_tcp_hdr_t *tcp_hdr = (sr_tcp_hdr_t *)(ip_hdr + sizeof(sr_ip_hdr_t));
            tcp_hdr->tcp_src_port = port_or_id;
        }
        icmp_t3_hdr->icmp_sum = 0;
        icmp_t3_hdr->icmp_sum = cksum(icmp_t3_hdr, icmp_len);
    }
}


void send_lookup_packet(
    struct sr_instance *sr,
    uint8_t* packet,
    uint32_t next_hop_ip,
    unsigned int packet_len,
    char* des_iface_name) {

    struct sr_arpentry * entry = sr_arpcache_lookup(&(sr->cache), next_hop_ip);

    if (entry) {
        memcpy(packet, entry->mac, ETHER_ADDR_LEN);
        memcpy(packet + ETHER_ADDR_LEN, (sr_get_interface(sr, des_iface_name))->addr, ETHER_ADDR_LEN);

        sr_send_packet(sr, packet, packet_len, des_iface_name);
        /* you must free the returned structure if it is not null */
        free(entry);
    }
    else {
        struct sr_arpreq *req = sr_arpcache_queuereq(&(sr->cache), next_hop_ip, packet, packet_len, des_iface_name);
        handle_arpreq(sr, req);
    }
}

void send_icmp_packet_portunreach(
    struct sr_instance* sr,
    uint8_t * packet,
    char* interface,
    uint32_t next_hop_ip,
    int in_icmp_type,
    int in_icmp_code) {

    sr_ip_hdr_t* ip_hdr = (sr_ip_hdr_t*)(packet + sizeof(sr_ethernet_hdr_t));

    sr_ip_hdr_t* sr_icmp_ip_hdr = (sr_ip_hdr_t*)malloc(sizeof(sr_ip_hdr_t));
    sr_icmp_ip_hdr->ip_v = 4;
    sr_icmp_ip_hdr->ip_hl = sizeof(sr_ip_hdr_t) / 4;
    sr_icmp_ip_hdr->ip_tos = 0;
    sr_icmp_ip_hdr->ip_len = htons(sizeof(sr_ip_hdr_t) + sizeof(sr_icmp_t3_hdr_t));
    sr_icmp_ip_hdr->ip_id = ip_hdr->ip_id;
    sr_icmp_ip_hdr->ip_off = htons(IP_DF);
    sr_icmp_ip_hdr->ip_ttl = 64;
    sr_icmp_ip_hdr->ip_p = ip_protocol_icmp;
    sr_icmp_ip_hdr->ip_src = ip_hdr->ip_dst;
    sr_icmp_ip_hdr->ip_dst = ip_hdr->ip_src;
    sr_icmp_ip_hdr->ip_sum = 0;
    sr_icmp_ip_hdr->ip_sum = cksum(sr_icmp_ip_hdr, sizeof(sr_ip_hdr_t));

    sr_icmp_t3_hdr_t* icmp_t3_hdr = (sr_icmp_t3_hdr_t*)malloc(sizeof(sr_icmp_t3_hdr_t));
    icmp_t3_hdr->icmp_type = in_icmp_type;
    icmp_t3_hdr->icmp_code = in_icmp_code;
    icmp_t3_hdr->icmp_sum = 0;
    icmp_t3_hdr->unused = 0;
    icmp_t3_hdr->next_mtu = 0;

    memcpy(icmp_t3_hdr->data, packet + sizeof(sr_ethernet_hdr_t), ICMP_DATA_SIZE);
    icmp_t3_hdr->icmp_sum = cksum(icmp_t3_hdr, sizeof(sr_icmp_t3_hdr_t));

    sr_ethernet_hdr_t* sr_ethernet_hdr = (sr_ethernet_hdr_t*)malloc(sizeof(sr_ethernet_hdr_t));
    memcpy(sr_ethernet_hdr->ether_dhost, ((sr_ethernet_hdr_t *)packet)->ether_shost, ETHER_ADDR_LEN);
    memcpy(sr_ethernet_hdr->ether_shost, sr_get_interface(sr, interface)->addr, ETHER_ADDR_LEN);
    sr_ethernet_hdr->ether_type = htons(ethertype_ip);

    int total_size = sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t) + sizeof(sr_icmp_t3_hdr_t);
    uint8_t* icmp_packet = (uint8_t*)malloc(total_size);
    memcpy(icmp_packet, sr_ethernet_hdr, sizeof(sr_ethernet_hdr_t));
    memcpy(icmp_packet + sizeof(sr_ethernet_hdr_t), sr_icmp_ip_hdr, sizeof(sr_ip_hdr_t));
    memcpy(icmp_packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t), icmp_t3_hdr, sizeof(sr_icmp_t3_hdr_t));

    send_lookup_packet(sr, icmp_packet, next_hop_ip, total_size, interface);

    free(sr_icmp_ip_hdr);
    free(sr_ethernet_hdr);
    free(icmp_packet);
    free(icmp_t3_hdr);
}
