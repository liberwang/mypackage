
#include <signal.h>
#include <assert.h>
#include "sr_nat.h"
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "sr_if.h"
#include "sr_router.h"
#include "sr_utils.h"
#include "sr_rt.h"

int sr_nat_init(struct sr_instance* sr, struct sr_nat *nat) { /* Initializes the nat */

  assert(nat);

  /* Acquire mutex lock */
  pthread_mutexattr_init(&(nat->attr));
  pthread_mutexattr_settype(&(nat->attr), PTHREAD_MUTEX_RECURSIVE);
  int success = pthread_mutex_init(&(nat->lock), &(nat->attr));

  /* Initialize timeout thread */

  pthread_attr_init(&(nat->thread_attr));
  pthread_attr_setdetachstate(&(nat->thread_attr), PTHREAD_CREATE_JOINABLE);
  pthread_attr_setscope(&(nat->thread_attr), PTHREAD_SCOPE_SYSTEM);
  pthread_attr_setscope(&(nat->thread_attr), PTHREAD_SCOPE_SYSTEM);
  pthread_create(&(nat->thread), &(nat->thread_attr), sr_nat_timeout, sr);

  /* CAREFUL MODIFYING CODE ABOVE THIS LINE! */

  nat->mappings = NULL;
  nat->syn_cache = NULL;
  /* Initialize any variables here */  
  nat->icmp_id_counter = 0;
  nat->tcp_port_counter = 0;
  return success;
}


int sr_nat_destroy(struct sr_nat *nat) {  /* Destroys the nat (free memory) */
  assert(nat);
  pthread_mutex_lock(&(nat->lock));

  /* free nat memory here */
  struct sr_nat_mapping * temp_mapping;
  struct sr_nat_mapping * current_mapping = nat->mappings;
  struct sr_nat_connection * temp_connection;
  struct sr_nat_connection * current_connection;
  
  while (current_mapping != NULL) {
	  current_connection = current_mapping->conns;
	  while (current_connection != NULL) {
		  temp_connection = current_connection;
		  current_connection = current_connection->next;
		  free(temp_connection);
	  }
	  temp_mapping = current_mapping;
	  current_mapping = current_mapping->next;
	  free(temp_mapping);
  }
	struct sr_nat_tcp_packet *curr_syn_packet = nat->syn_cache;
	struct sr_nat_tcp_packet *next_syn_packet = NULL;
	while (curr_syn_packet != NULL) {
			next_syn_packet = curr_syn_packet->next;
			if (curr_syn_packet->buf)
				free(curr_syn_packet->buf);
			free(curr_syn_packet);
			curr_syn_packet = next_syn_packet;
	}
  free(nat);

  pthread_kill(nat->thread, SIGKILL);
  return pthread_mutex_destroy(&(nat->lock)) &&
    pthread_mutexattr_destroy(&(nat->attr));

}

void *sr_nat_timeout(void *sr_prt) {  /* Periodic Timout handling */
  struct sr_instance* sr = (struct sr_instance *) sr_prt;
  struct sr_nat *nat = sr->nat;
  while (1) {
    sleep(1.0);
    pthread_mutex_lock(&(nat->lock));

    time_t curtime = time(NULL);
    
    /* handle periodic tasks here */
    struct sr_nat_mapping *cur_mapping = nat->mappings;
	struct sr_nat_mapping *prev_mapping = NULL;
	struct sr_nat_mapping *next_mapping = NULL;
    
    while (cur_mapping != NULL) {
		int time_passed = curtime - cur_mapping->last_updated;
		if (cur_mapping->type == nat_mapping_icmp) {
			if (time_passed > nat->icmp_query_timeout) {
                if (prev_mapping) {
                     prev_mapping->next = cur_mapping->next;
                }
                else {
                    nat->mappings = cur_mapping->next;
                }
				next_mapping = cur_mapping->next;
				free(cur_mapping);
				cur_mapping = next_mapping;
			} else {
				prev_mapping = cur_mapping;
				cur_mapping = cur_mapping->next;
			}
		} else if (cur_mapping->type == nat_mapping_tcp){
			/* check TCP connections*/
			struct sr_nat_connection *cur_conn = cur_mapping->conns;
			struct sr_nat_connection *prev_conn = NULL;
			struct sr_nat_connection *next_conn = NULL;
			while (cur_conn != NULL) {
				time_passed = curtime - cur_conn->last_updated;
				if ((cur_conn->state == ESTAB 
				&& time_passed > nat->tcp_established_timeout) 
				|| (time_passed > nat->tcp_transitory_timeout)
				|| (cur_conn->state == CLOSED)) {
                    if (prev_conn) {
                        prev_conn->next = cur_conn->next;
                    }
                    else {
                        cur_mapping->conns = cur_conn->next;
                    }
					next_conn  = cur_conn->next;
					free(cur_conn);
					cur_conn = next_conn;
				} else {
					prev_conn = cur_conn;
					cur_conn = cur_conn->next;
				}
			}
			if (cur_mapping->conns == NULL){
                if (prev_mapping) {
                    prev_mapping->next = cur_mapping->next;
                }
                else {
                    nat->mappings = cur_mapping->next;
                }
				next_mapping = cur_mapping->next;
				free(cur_mapping);
				cur_mapping = next_mapping;
			} else {
				prev_mapping = cur_mapping;
				cur_mapping = cur_mapping->next;
			}
		}
	}
	
    struct sr_nat_tcp_packet *curr_syn_packet = nat->syn_cache;
    struct sr_nat_tcp_packet *prev_syn_packet = NULL;
	struct sr_nat_tcp_packet *next_syn_packet = NULL;
	while (curr_syn_packet != NULL) {
		int time_passed = curtime - curr_syn_packet->time_received;
		if ( time_passed > 6 ){
            if (prev_syn_packet) {
                prev_syn_packet->next = curr_syn_packet->next;
            }
            else {
                nat->syn_cache = curr_syn_packet->next;
            }
			next_syn_packet = curr_syn_packet->next;
			sr_ip_hdr_t* org_ip_hdr = (sr_ip_hdr_t *)(curr_syn_packet->buf + sizeof(sr_ethernet_hdr_t));
			struct sr_rt* rt_entry = search_longest_prefix(sr, org_ip_hdr->ip_src);
			if (rt_entry == NULL){
				pthread_mutex_unlock(&(nat->lock));
				return NULL;
			}
			send_icmp_packet(sr, curr_syn_packet->buf, rt_entry->interface, org_ip_hdr->ip_dst, rt_entry->gw.s_addr, 3, 3);
			if (curr_syn_packet->buf)
				free(curr_syn_packet->buf);
			free(curr_syn_packet);
			curr_syn_packet = next_syn_packet;
		}else{
			prev_syn_packet = curr_syn_packet;
			next_syn_packet = curr_syn_packet->next;
			curr_syn_packet = next_syn_packet;
		}
	}
    pthread_mutex_unlock(&(nat->lock));
  }
  return NULL;
}

/* Get the mapping associated with given external port.
   You must free the returned structure if it is not NULL. */
struct sr_nat_mapping *sr_nat_lookup_external(struct sr_nat *nat,
    uint16_t aux_ext, sr_nat_mapping_type type ) {

  pthread_mutex_lock(&(nat->lock));

  /* handle lookup here, malloc and assign to copy */
  struct sr_nat_mapping *copy = NULL;

  struct sr_nat_mapping *current_mapping = nat->mappings;
  while(current_mapping != NULL) {
	  if (current_mapping->type == type 
	  && current_mapping->aux_ext == aux_ext){
		  copy =  (struct sr_nat_mapping *)malloc(sizeof(struct sr_nat_mapping));
		  current_mapping->last_updated = time(NULL);
		  memcpy(copy, current_mapping, sizeof(struct sr_nat_mapping));
		  pthread_mutex_unlock(&(nat->lock));
          return copy;
	  }
      current_mapping = current_mapping->next;
  }
  pthread_mutex_unlock(&(nat->lock));
  return copy;
}

/* Get the mapping associated with given internal (ip, port) pair.
   You must free the returned structure if it is not NULL. */
struct sr_nat_mapping *sr_nat_lookup_internal(struct sr_nat *nat,
        uint32_t ip_int, uint16_t aux_int, sr_nat_mapping_type type ) {

    pthread_mutex_lock(&(nat->lock));

    /* handle lookup here, malloc and assign to copy. */
    struct sr_nat_mapping *copy = NULL;

    struct sr_nat_mapping *current_mapping = nat->mappings;
    while (current_mapping != NULL) {
		if(current_mapping->type == type 
		&& current_mapping->ip_int == ip_int 
		&& current_mapping->aux_int == aux_int){
            copy = (struct sr_nat_mapping *)malloc(sizeof(struct sr_nat_mapping));
            current_mapping->last_updated = time(NULL);
            memcpy(copy, current_mapping, sizeof(struct sr_nat_mapping));
			pthread_mutex_unlock(&(nat->lock));
            return copy;
        }
        current_mapping = current_mapping->next;
    }
    pthread_mutex_unlock(&(nat->lock));
    return copy;
}



/* Insert a new mapping into the nat's mapping table.
   Actually returns a copy to the new mapping, for thread safety.
 */
struct sr_nat_mapping *sr_nat_insert_mapping(struct sr_instance* sr, struct sr_nat *nat,
  uint32_t ip_int, uint16_t aux_int, sr_nat_mapping_type type,  char* interface) {

  pthread_mutex_lock(&(nat->lock));

  /* handle insert here, create a mapping, and then return a copy of it */
  struct sr_nat_mapping *new_mapping 
  = (struct sr_nat_mapping *)malloc(sizeof(struct sr_nat_mapping));
  
  /*struct sr_if* ex_if_entry = sr_get_interface(sr, EXTERNAL_IF);*/
  
  new_mapping->ip_int = ip_int;
  new_mapping->aux_int = aux_int;
  new_mapping->ip_ext = sr_get_interface(sr, interface)->ip;
  if (type == nat_mapping_icmp) { /* ICMP ID*/
	  new_mapping->aux_ext = htons(sr_nat_gen_port(nat, 0));
  } else if (type == nat_mapping_tcp){ /* TCP port*/
	  new_mapping->aux_ext = htons(sr_nat_gen_port(nat, 1024));
  }
  new_mapping->last_updated = time(NULL);
  new_mapping->conns = NULL; /*TODO: add new connection*/
  new_mapping->type = type;
  /*put new mapping on top of the list*/
  new_mapping->next = nat->mappings;
  nat->mappings = new_mapping;
  
  struct sr_nat_mapping *copy = (struct sr_nat_mapping *)malloc(sizeof(struct sr_nat_mapping));
  memcpy(copy, new_mapping, sizeof(struct sr_nat_mapping));
  pthread_mutex_unlock(&(nat->lock));
  return copy;
}


struct sr_nat_connection *sr_nat_lookup_conn(struct sr_nat *nat, struct sr_nat_mapping *mapping,
          uint32_t ip_src, uint32_t ip_dst, uint16_t port_src, uint16_t port_dst) {

    pthread_mutex_lock(&(nat->lock));
	assert(nat);
	assert(mapping);
    /* handle lookup here, malloc and assign to copy. */
    struct sr_nat_connection *copy = NULL;

    struct sr_nat_connection *current_conn = mapping->conns;
    while (current_conn != NULL) {
		print_addr_ip_int(current_conn->ip_src);
		print_addr_ip_int(ip_src);
		print_addr_ip_int(current_conn->ip_dst);
		print_addr_ip_int(ip_dst);
		if(current_conn->ip_src == ip_src 
		&& current_conn->ip_dst == ip_dst
		&& current_conn->port_src == port_src 
		&& current_conn->port_dst == port_dst){
            copy = (struct sr_nat_connection *)malloc(sizeof(struct sr_nat_connection));
            current_conn->last_updated = time(NULL);
            memcpy(copy, current_conn, sizeof(struct sr_nat_connection));
			pthread_mutex_unlock(&(nat->lock));
            return copy;
        }
        current_conn = current_conn->next;
    }
    
    pthread_mutex_unlock(&(nat->lock));
    return copy;
}

struct sr_nat_connection *sr_nat_insert_conn(struct sr_nat *nat, struct sr_nat_mapping *mapping,
  uint32_t ip_src, uint32_t ip_dst, uint16_t port_src, uint16_t port_dst) {

  pthread_mutex_lock(&(nat->lock));

	assert(nat);
	assert(mapping);

	struct sr_nat_mapping *mappings = nat->mappings;
	while (mappings != NULL && (mappings->aux_ext != mapping->aux_ext || mappings->type != mapping->type)){
		mappings = mappings->next;
	}
	if (mappings == NULL){
		pthread_mutex_unlock(&(nat->lock));
		return NULL;
	}

  /* handle insert here, create a connection, and then return a copy of it */
  struct sr_nat_connection *new_conn = (struct sr_nat_connection *)malloc(sizeof(struct sr_nat_connection));
  
  new_conn->ip_src = ip_src;
  new_conn->ip_dst = ip_dst;
  new_conn->port_src = port_src;
  new_conn->port_dst = port_dst;
  new_conn->last_updated = time(NULL);
  new_conn->seq_num_in = 0;
  new_conn->seq_num_out = 0;
  new_conn->state = DEFAULT;
  new_conn->next = mappings->conns;
  mappings->conns = new_conn;
  
  struct sr_nat_connection * copy = (struct sr_nat_connection *)malloc(sizeof(struct sr_nat_connection));
  memcpy(copy, new_conn, sizeof(struct sr_nat_connection));
  pthread_mutex_unlock(&(nat->lock));
  return copy;
}

void sr_nat_add_syn_cache (struct sr_nat *nat, uint8_t *packet, unsigned int packet_len) {
	pthread_mutex_lock(&(nat->lock));
	
	struct sr_nat_tcp_packet *pkt;
    for (pkt = nat->syn_cache; pkt != NULL; pkt = pkt->next) {
		uint8_t * buf = pkt->buf;
		sr_ip_hdr_t* ip_hdr_ptr = (sr_ip_hdr_t*)(buf + sizeof(sr_ethernet_hdr_t));
		sr_tcp_hdr_t* tcp_hdr_ptr = (sr_tcp_hdr_t*)(buf + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
		sr_ip_hdr_t* com_ip_hdr_ptr = (sr_ip_hdr_t*)(packet + sizeof(sr_ethernet_hdr_t));
		sr_tcp_hdr_t* com_tcp_hdr_ptr = (sr_tcp_hdr_t*)(packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));

		print_hdr_ip((uint8_t *)ip_hdr_ptr);
		print_hdr_ip((uint8_t *)com_ip_hdr_ptr);
		
        if (ip_hdr_ptr->ip_src == com_ip_hdr_ptr->ip_src 
        && ip_hdr_ptr->ip_dst == com_ip_hdr_ptr->ip_dst 
        && tcp_hdr_ptr->tcp_dst_port == com_tcp_hdr_ptr->tcp_dst_port
        && tcp_hdr_ptr->tcp_src_port == com_tcp_hdr_ptr->tcp_src_port) {
			pthread_mutex_unlock(&(nat->lock));
			
            return;
        }
    }
	

    if (packet && packet_len) {
        struct sr_nat_tcp_packet *new_pkt = (struct sr_nat_tcp_packet *)malloc(sizeof(struct sr_nat_tcp_packet));
        new_pkt->buf = (uint8_t *)malloc(packet_len);
        memcpy(new_pkt->buf, packet, packet_len);
        new_pkt->len = packet_len;
        new_pkt->time_received = time(NULL);
        new_pkt->next = nat->syn_cache;
        nat->syn_cache = new_pkt;
    }
    pthread_mutex_unlock(&(nat->lock));
}

void sr_nat_remove_syn_packet (struct sr_nat *nat, int32_t ip_dst, uint16_t port_dst, uint16_t port_src){
	pthread_mutex_lock(&(nat->lock));
	struct sr_nat_tcp_packet *curr_syn_packet = nat->syn_cache;
	struct sr_nat_tcp_packet *prev_syn_packet = NULL;
	struct sr_nat_tcp_packet *next_syn_packet = NULL;
	
	while(curr_syn_packet != NULL){
		
		sr_ip_hdr_t* ip_hdr_ptr = (sr_ip_hdr_t*)(curr_syn_packet->buf + sizeof(sr_ethernet_hdr_t));
		sr_tcp_hdr_t* tcp_hdr_ptr = (sr_tcp_hdr_t*)(curr_syn_packet->buf + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
		
		if (ip_hdr_ptr->ip_src == ip_dst 
		&& tcp_hdr_ptr->tcp_dst_port == port_src 
		&& tcp_hdr_ptr->tcp_src_port == port_dst){
            if (prev_syn_packet) {
                prev_syn_packet->next = curr_syn_packet->next;
            }
            else {
                nat->syn_cache = curr_syn_packet->next;
            }

			next_syn_packet = curr_syn_packet->next;
			if (curr_syn_packet->buf)
				free(curr_syn_packet->buf);
			free(curr_syn_packet);
		}else{
			prev_syn_packet = curr_syn_packet;
			next_syn_packet = curr_syn_packet->next;
		}
		curr_syn_packet = next_syn_packet;
	}
	pthread_mutex_unlock(&(nat->lock));
}



uint16_t sr_nat_gen_port(struct sr_nat *nat, uint16_t init){ 
	pthread_mutex_lock(&(nat->lock));
	struct sr_nat_mapping* mapping_entry; 
	mapping_entry = nat->mappings; 
	srand(time(NULL));
	int r = rand();
	uint16_t p = (uint16_t)(r%(65535-init) + init); 
	uint8_t exist; 
	while(p <= 65535){
		exist = 1;
		while(mapping_entry != NULL){ 
			if((ntohs(mapping_entry->aux_ext) == p && mapping_entry->type == nat_mapping_tcp) || p == 8888){ 
				p++; 
				exist = 0;
			}
			mapping_entry = mapping_entry->next; 
		} 
		mapping_entry = nat->mappings;
		if(exist == 1){ 
			pthread_mutex_unlock(&(nat->lock));
			return p; 
		} 
	} 
	pthread_mutex_unlock(&(nat->lock));
	return p; 
}

int change_conn_state(struct sr_nat *nat, struct sr_nat_mapping* mapping, sr_tcp_hdr_t * tcp_hdr_ptr, struct sr_nat_connection * conn, int in_to_ex){
	pthread_mutex_lock(&(nat->lock));
	
	if (mapping == NULL || conn == NULL){
		pthread_mutex_unlock(&(nat->lock));
		return 0;
	}
	
	struct sr_nat_mapping *mappings = nat->mappings;
	struct sr_nat_connection * conns = NULL;
	while (mappings != NULL && (mappings->aux_ext != mapping->aux_ext || mappings->type != mapping->type)){
		mappings = mappings->next;
	}
	if (mappings != NULL){
		conns =  mappings->conns;
		while (conns != NULL && (conns->ip_dst != conn->ip_dst || conns->port_dst != conn->port_dst)){
			conns = conns->next;
		}
	}
	if (conns == NULL){
		pthread_mutex_unlock(&(nat->lock));
		return 0;
	}
    uint16_t control_bits = ntohs(tcp_hdr_ptr->tcp_ctl_bits) & 19;  /* ACK, SYN, FIN*/
    int ret_val = 1;

    switch(conns->state){
		case CLOSED:
		    if (in_to_ex && (control_bits & 2) == 2) { /*snd SYN*/
                conns->state = SYN_SENT;
                conns->seq_num_out = tcp_hdr_ptr->tcp_seq_num;
                ret_val = 1;
            }
            break;
        case LISTEN:
            break;
        case LISTEN_RCV_SYN:
            break;
        case SYN_RCVD:
            if (!in_to_ex && (control_bits & 16) == 16
            && ntohl(tcp_hdr_ptr->tcp_ack_num) == (ntohl(conns->seq_num_out)+1)){ /*rcv ACK */
                conns->state = ESTAB;
                conns->seq_num_out = 0;
                ret_val = 1;
            } else if (in_to_ex && (control_bits & 1) == 1){ /*snd FIN */
                conns->state = FIN_WAIT_1;
                conns->seq_num_out = 0;
                ret_val = 1;
            }
            break;
        case SYN_SENT:
            if (!in_to_ex && (control_bits & 18) == 18
            && ntohl(tcp_hdr_ptr->tcp_ack_num) == (ntohl(conns->seq_num_out)+1)) { /* rcv ACK, SYN*/
                conns->state = SYN_SENT_RCV_SYN_ACK;
                conns->seq_num_in = tcp_hdr_ptr->tcp_seq_num;
                ret_val = 1;
            } else if (!in_to_ex && (control_bits & 0x2) == 0x2){/* rcv SYN*/
                conns->state = SYN_SENT_RCV_SYN;
                conns->seq_num_in = tcp_hdr_ptr->tcp_seq_num;
                ret_val = 1;
            }
            break;
        case SYN_SENT_RCV_SYN:
            if (in_to_ex && (control_bits & 16) == 16
            && ntohl(tcp_hdr_ptr->tcp_ack_num) == (ntohl(conns->seq_num_in)+1)) { /*snd ACK*/
                conns->state = SYN_RCVD;
                conns->seq_num_in = 0;
                ret_val = 1;
            }
            break;
        case SYN_SENT_RCV_SYN_ACK:
            if (in_to_ex && (control_bits & 16) == 16
            && ntohl(tcp_hdr_ptr->tcp_ack_num) == (ntohl(conns->seq_num_in)+1)){ /*snd ACK */
                conns->state = ESTAB;
                conns->seq_num_in = 0;
                ret_val = 1;
            }
            break;
        case ESTAB:
        
            if (in_to_ex && (control_bits & 1) == 1){ /*snd FIN */
                conns->state = FIN_WAIT_1;
                conns->seq_num_out = tcp_hdr_ptr->tcp_seq_num;
                ret_val = 1;
            } else if (!in_to_ex && (control_bits & 1) == 1){ /*rcv FIN */
                conns->state = ESTAB_RCV_FIN;
                conns->seq_num_in = tcp_hdr_ptr->tcp_seq_num;
                ret_val = 1;
            }else{
			    ret_val = 1;
		    }
            break;
        case ESTAB_RCV_FIN:
            if (in_to_ex && (control_bits & 16) == 16
            && ntohl(tcp_hdr_ptr->tcp_ack_num) == (ntohl(conns->seq_num_in))){ /*snd ACK */
                conns->state = CLOSE_WAIT;
                conns->seq_num_in = 0;
                ret_val = 1;
            } else if (in_to_ex && (control_bits & 17)== 17
            && ntohl(tcp_hdr_ptr->tcp_ack_num) == (ntohl(conns->seq_num_in))){ /*snd ACK FIN*/
			    conns->state = LAST_ACK;
                conns->seq_num_out = tcp_hdr_ptr->tcp_seq_num;
                ret_val = 1;
		    }
            break;
        case FIN_WAIT_1:
            if (!in_to_ex && (control_bits & 16) == 16
            && ntohl(tcp_hdr_ptr->tcp_ack_num) == (ntohl(conns->seq_num_out)+1)){ /*rcv ACK */
                conns->state = FIN_WAIT_2;
                conns->seq_num_out = 0;
                ret_val = 1;
            } else if (!in_to_ex && (control_bits & 1)== 1){ /*rcv FIN */
                conns->state = FIN_WAIT_1_RCV_FIN;
                conns->seq_num_in = tcp_hdr_ptr->tcp_seq_num;
                ret_val = 1;
            }
            break;
        case FIN_WAIT_1_RCV_FIN:
            if (in_to_ex && (control_bits & 16) == 16
            && ntohl(tcp_hdr_ptr->tcp_ack_num) == (ntohl(conns->seq_num_in)+1)){ /*snd ACK */
                conns->state = CLOSING;
                conns->seq_num_in = 0;
                ret_val = 1;
            }
            break;
        case CLOSE_WAIT:
            if (in_to_ex && (control_bits & 3) == 1){ /*snd FIN */
                conns->state = LAST_ACK;
                conns->seq_num_out = tcp_hdr_ptr->tcp_seq_num;
                ret_val = 1;
            }
            break;
        case FIN_WAIT_2:
            if (!in_to_ex && (control_bits & 1) == 1){ /*rcv FIN */
                conns->state = FIN_WAIT_2_RCV_FIN;
                conns->seq_num_in = tcp_hdr_ptr->tcp_seq_num;
                ret_val = 1;
            }
            break;
        case FIN_WAIT_2_RCV_FIN:
            if (in_to_ex && (control_bits & 16) == 16
            && ntohl(tcp_hdr_ptr->tcp_ack_num) == (ntohl(conns->seq_num_in)+1)){ /*snd ACK */
                conns->state = CLOSED; /*skip TIME_WAIT*/
                conns->seq_num_in = 0;
                ret_val = 1;
            }
            break;
        case CLOSING:
            if (!in_to_ex && (control_bits & 16) == 16
            && ntohl(tcp_hdr_ptr->tcp_ack_num) == (ntohl(conns->seq_num_out)+1)){ /*rcv ACK */
                conns->state = CLOSED; /*skip TIME_WAIT*/
                conns->seq_num_out = 0;
                ret_val = 1;
            }
            break;
        case LAST_ACK:
            if (!in_to_ex && (control_bits & 16) == 16
            && ntohl(tcp_hdr_ptr->tcp_ack_num) == (ntohl(conns->seq_num_out)+1)){ /*rcv ACK */
                conns->state = CLOSED;
                conns->seq_num_out = 0;
                ret_val = 1;
            }
            break;
        case TIME_WAIT:
        break;
        
        default:
            if (in_to_ex && (control_bits & 2) == 2) { /*snd SYN*/
                conns->state = SYN_SENT;
                conns->seq_num_out = tcp_hdr_ptr->tcp_seq_num;
                ret_val = 1;
            }
            break;
    }
    pthread_mutex_unlock(&(nat->lock));
    return ret_val;
    
}
